Place images, fonts, icons, and other static assets in this folder.
Reference them from HTML/CSS as: assets/your-file.png
