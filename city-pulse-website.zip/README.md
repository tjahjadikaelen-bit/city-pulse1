# City Pulse — Smart Urban Mobility Jakarta

Static website. Open `index.html` in a browser, or deploy the whole folder to any static host (Netlify, Vercel, GitHub Pages, etc.).

## Structure
- `index.html` — entry point (root)
- `css/styles.css` — all styles
- `js/main.js` — all scripts
- `assets/` — images and other static files
